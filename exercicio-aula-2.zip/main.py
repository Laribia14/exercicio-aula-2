def exibir_menu(): 

    print("\nMenu:") 

    print("1. Criar Turma") 

    print("2. Adicionar Professor") 

    print("3. Adicionar Estudante") 

    print("4. Adicionar Nota") 

    print("5. Consultar Nota") 

    print("6. Salvar Nota") 

    print("7. Sair") 



def menu_interativo(): 

    while True: 

        exibir_menu() 

        opcao = input("Escolha uma opção: ") 



        if opcao == '1': 

            print("Você escolheu: Criar Turma") 

        elif opcao == '2': 

            print("Você escolheu: Adicionar Professor") 

        elif opcao == '3': 

            print("Você escolheu: Adicionar Estudante") 

        elif opcao == '4': 

            print("Você escolheu: Adicionar Nota") 

        elif opcao == '5': 

            print("Você escolheu: Consultar Nota") 

        elif opcao == '6': 

            print("Você escolheu: Salvar Nota") 

        elif opcao == '7': 

            print("Saindo...") 

            break 

        else: 

            print("Opção inválida. Tente novamente.") 



if __name__ == "__main__": 

    menu_interativo() 
